﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.$rootnamespace$;

namespace $rootnamespace$
{
    public class $safeitemname$ : Task
    {
        public override bool Execute()
        {
            Log.LogWarning("Custom Code Task executed");
            return true;
        }
    }
}
